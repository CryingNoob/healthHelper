const app = getApp()
Page({
  tofall () {
    wx.navigateTo({
      url: '../map/map'
    })
  },
  onShareAppMessage () {
    return {
      title: '快来使用健康小助手',
      imageUrl: '../../asset/logo.png'
    }
  }
})
