const envList = [{"envId":"cloud1-5gzfe7d8a97ba290","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}