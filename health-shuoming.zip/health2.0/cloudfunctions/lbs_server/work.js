const request = require('request') // 引用request模块
const { key } = require('./config.json') // 引用地图信息配置
const cloud=require('wx-server-sdk')
cloud.init()
/**
 * 加载经纬度详细地址信息
 * @param {*} event
 */
async function location (event) {
  const res = { code: -1 } // 默认返回对象，code为-1
  try {
    const result = await call({ location: event.location }) // 调用request请求封装，传入经纬度信息
    if (result.formatted_addresses != null) { // 如果返回有推荐地址，正常返回信息
      res.code = 0
      res.formatted = result.formatted_addresses.recommend
      res.location = `${result.location.lat.toFixed(4)},${result.location.lng.toFixed(4)}`
      res.address = result.address
      res.adinfo = result.ad_info.name
      res.reallocal = result.location
    } else { // 没有推荐地址，说明不在国内，提示返回
      res.msg = '请确认经纬度在中国区域'
    }
  } catch (e) { // 有接口其他问题，直接返回提示
    res.msg = e
  }
  return res
}

/**
 * 加载地址的详细信息
 * @param {*} event
 */
async function address (event) {
  try {
    const locres = await call({ address: encodeURIComponent(event.address || '深圳市南山区深南大道10000号') }) // 传入编码后的地址，如果为空默认是腾讯大厦
    return await location({ location: `${locres.location.lat},${locres.location.lng}` }) // 如果正常返回，则找到坐标点了，传入经纬度信息方法，获取详细，上面的接口不管用
  } catch (e) {
    return { // 有接口其他问题，直接返回提示
      code: -1,
      msg: e
    }
  }
}
/**
 * helpme详细信息
 * @param {*} event
 */
async function helpme(event){
  
  
  var res= await message(event.number,event.info);
  var result = {
    code:0,
    res1:res
  }// 默认返回对象
  // var reg = /.+?(省|市|自治区|自治州|县|区|路)/g;
  // var address=event.info.address.match(reg)
  // str1=address[0]+address[1]
  // str1=str1.slice(0,str1.length-1)
  // str2= address[2]+address[3]
  // str2=str2.slice(0,str2.length-1)
  // var result={
  //   code:0,
  //   data:{
  //     a:str1,
  //   b:str2,
  //     e:event.info.formatted
  //   }
  // }
return  result
  
}
async function message(phone, info){

  /**
   * 分离出省市信息减少变量长度
   */
  var reg = /.+?(省|市|自治区|自治州|县|区|路|街)/g;
  var address=info.address.match(reg)
  str1=address[0]+address[1]
  str1=str1.slice(0,str1.length-1)
  str2= address[2]+address[3]
  str2=str2.slice(0,str2.length-1)


  var str3=info.formatted
  str3.replace(/\[.*?\]/g, '' )
  str3.replace(/\(.*?\)/g, '' )
  str3 = str3.includes('市') ? str3.replace(/市/, ' ').split(' ')[1] : str3
  str3 = str3.includes('区') ? str3.replace(/区/, ' ').split(' ')[1] : str3
  if(str3.length>12)
  str3=str3.slice(0,12)
  
  const tencentcloud = require("tencentcloud-sdk-nodejs")

  // 导入对应产品模块的client models。
  const smsClient = tencentcloud.sms.v20210111.Client
  
  /* 实例化要请求产品(以sms为例)的client对象 */
  const client = new smsClient({
    credential: {
    /* 必填：腾讯云账户密钥对secretId，secretKey。
     * 这里采用的是从环境变量读取的方式，需要在环境变量中先设置这两个值。
     * 你也可以直接在代码中写死密钥对，但是小心不要将代码复制、上传或者分享给他人，
     * 以免泄露密钥对危及你的财产安全。
     * SecretId、SecretKey 查询: https://console.cloud.tencent.com/cam/capi */
      secretId: 'AKIDmNinb8ON6YkfJgmb8PO6XhaBVZMs75nD',
      secretKey: 'A3g15rNbYDbicFbgU1HGyOXOzJL6bpmS',
    },
    /* 必填：地域信息，可以直接填写字符串ap-guangzhou，支持的地域列表参考 https://cloud.tencent.com/document/api/382/52071#.E5.9C.B0.E5.9F.9F.E5.88.97.E8.A1.A8 */
    region: "ap-beijing",
    /* 非必填:
     * 客户端配置对象，可以指定超时时间等配置 */
    profile: {
      /* SDK默认用TC3-HMAC-SHA256进行签名，非必要请不要修改这个字段 */
      signMethod: "HmacSHA256",
      httpProfile: {
        /* SDK默认使用POST方法。
         * 如果你一定要使用GET方法，可以在这里设置。GET方法无法处理一些较大的请求 */
        reqMethod: "POST",
        /* SDK有默认的超时时间，非必要请不要进行调整
         * 如有需要请在代码中查阅以获取最新的默认值 */
        reqTimeout: 30,
        /**
         * 指定接入地域域名，默认就近地域接入域名为 sms.tencentcloudapi.com ，也支持指定地域域名访问，例如广州地域的域名为 sms.ap-guangzhou.tencentcloudapi.com
         */
        endpoint: "sms.tencentcloudapi.com"
      },
    },
  })
  
  /* 请求参数，根据调用的接口和实际情况，可以进一步设置请求参数
   * 属性可能是基本类型，也可能引用了另一个数据结构
   * 推荐使用IDE进行开发，可以方便的跳转查阅各个接口和数据结构的文档说明 */
  const params = {
    /* 短信应用ID: 短信SmsSdkAppId在 [短信控制台] 添加应用后生成的实际SmsSdkAppId，示例如1400006666 */
    SmsSdkAppId: "1400642255",
    /* 短信签名内容: 使用 UTF-8 编码，必须填写已审核通过的签名，签名信息可登录 [短信控制台] 查看 */
    SignName: "安全小卫士个人公众号",
    /* 短信码号扩展号: 默认未开通，如需开通请联系 [sms helper] */
    ExtendCode: "",
    /* 国际/港澳台短信 senderid: 国内短信填空，默认未开通，如需开通请联系 [sms helper] */
    SenderId: "",
    /* 用户的 session 内容: 可以携带用户侧 ID 等上下文信息，server 会原样返回 */
    SessionContext: "",
    /* 下发手机号码，采用 e.164 标准，+[国家或地区码][手机号]
     * 示例如：+8613711112222， 其中前面有一个+号 ，86为国家码，13711112222为手机号，最多不要超过200个手机号*/
    PhoneNumberSet: ["+86"+phone],
    /* 模板 ID: 必须填写已审核通过的模板 ID。模板ID可登录 [短信控制台] 查看 */
    TemplateId: "1325097",
    /* 模板参数: 若无模板参数，则设置为空*/
   
    TemplateParamSet: [str1,str2,str3],
  }
 //return " "+typeof(params.TemplateParamSet[0])+" "+typeof(info)
  // 通过client对象调用想要访问的接口，需要传入请求对象以及响应回调函数
  client.SendSms(params, function (err, response) {
    // 请求异常返回，打印异常信息
    if (err) {
      console.log(err)
      return "err"
    }
    // 请求正常返回，打印response对象
    console.log(response)
    return "response"
  })

}
/**
 * 封装的请求
 * @param {*} obj 请求信息
 */
function call (obj) {
  let url = `https://apis.map.qq.com/ws/geocoder/v1/?key=${key}` // API地址，加key
  for (const i in obj) { // 根据参数拼接API地址
    url += `&${i}=${obj[i]}`
  }
  console.log(url) // 显示一下，备份
  return new Promise((resolve, reject) => {
    request({ // 开始请求
      method: 'GET',
      url: url
    }, function (error, response) {
      if (error) reject(error) // 有问题，返回异常
      try {
        const result = JSON.parse(response.body) // 正常，解析内容
        if (result.status === 0) { // 如果为0，则接口正常返回
          resolve(result.result)
        } else { // 如果不为0，则有问题，返回提示
          reject(result.message)
        }
      } catch (e) { // 解析失败或其他问题，返回异常信息
        reject(e)
      }
    })
  })
}
module.exports = {
  address,
  location,
  helpme
}
